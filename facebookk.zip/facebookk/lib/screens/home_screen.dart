
import 'package:flutter/material.dart';
import '../widgets/story_widget.dart';
import '../widgets/post_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedTab = 0;

  final Color facebookBlue = const Color(0xFF1877F2);

  final List<Map<String, String>> stories = [
    {
      'name': 'Ahmed',
      'image': 'lib/assets/images/story1.jpeg',
    },
    {
      'name': 'Mona',
      'image': 'lib/assets/images/story2.jpeg',
    },
    {
      'name': 'Omar',
      'image': 'lib/assets/images/story3.jpeg',
    },
    {
      'name': 'Sara',
      'image': 'lib/assets/images/story4.jpeg',
    },
  ];

  Widget topBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 8,
      ),
      child: Row(
        children: [
          Text(
            'Facebook',
            style: TextStyle(
              color: facebookBlue,
              fontSize: 27,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Spacer(),
          CircleAvatar(
            radius: 17,
            backgroundColor: Colors.black87,
            child: IconButton(
              padding: EdgeInsets.zero,
              icon: const Icon(
                Icons.add,
                color: Colors.white,
                size: 20,
              ),
              onPressed: () {},
            ),
          ),
          const SizedBox(width: 12),
          const Icon(Icons.search, size: 27),
          const SizedBox(width: 12),
          const Icon(Icons.messenger, size: 25),
        ],
      ),
    );
  }

  Widget navigationBar() {
    final icons = [
      Icons.home,
      Icons.ondemand_video,
      Icons.storefront_outlined,
      Icons.person_outline,
      Icons.notifications_none,
    ];

    return Row(
      children: List.generate(icons.length, (index) {
        return Expanded(
          child: InkWell(
            onTap: () {
              setState(() {
                selectedTab = index;
              });
            },
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: selectedTab == index
                        ? facebookBlue
                        : Colors.transparent,
                    width: 3,
                  ),
                ),
              ),
              child: Icon(
                icons[index],
                color: selectedTab == index
                    ? facebookBlue
                    : Colors.blueGrey,
                size: 27,
              ),
            ),
          ),
        );
      }),
    );
  }

  Widget createPostBox() {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          const CircleAvatar(
            radius: 21,
            backgroundImage: AssetImage(
              'lib/assets/images/profile.jpeg',
            ),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: Text(
              "What's on Your Mind?",
              style: TextStyle(
                color: Color(0xFF898F9C),
                fontSize: 15,
              ),
            ),
          ),
          const Icon(
            Icons.image_outlined,
            color: Colors.green,
            size: 27,
          ),
        ],
      ),
    );
  }

  Widget storiesSection() {
    return SizedBox(
      height: 190,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        itemCount: stories.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return const StoryWidget(
              name: 'Create Story',
              imagePath: 'lib/assets/images/profile.jpeg',
              isCreateStory: true,
            );
          }

          return StoryWidget(
            name: stories[index - 1]['name']!,
            imagePath: stories[index - 1]['image']!,
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            topBar(),
            navigationBar(),
            const Divider(height: 1, thickness: 1),
            Expanded(
              child: ListView(
                children: [
                  createPostBox(),
                  const Divider(
                    height: 5,
                    thickness: 5,
                    color: Color(0xFFE4E6EB),
                  ),
                  storiesSection(),
                  const Divider(
                    height: 5,
                    thickness: 5,
                    color: Color(0xFFE4E6EB),
                  ),
                  PostWidget(
                    userName: 'Route',
                    time: '8h',
                    profileImage: 'lib/assets/images/profilepost.jpeg',
                    postImage: 'lib/assets/images/post.jpeg',
                    description: '',
                  ),
                  PostWidget(
                    userName: 'Ahmed',
                    time: '10h',
                    profileImage: 'lib/assets/images/profile1.jpeg',
                    postImage: 'lib/assets/images/story2.jpeg',
                    description: 'Enjoying a beautiful day!',
                  ),
                  PostWidget(
                    userName: 'Mona',
                    time: '1d',
                    profileImage: 'lib/assets/images/profile.jpeg',
                    postImage: 'lib/assets/images/story3.jpeg',
                    description: 'Beautiful moments ❤️',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
