
import 'package:flutter/material.dart';

class PostWidget extends StatefulWidget {
  final String userName;
  final String time;
  final String profileImage;
  final String postImage;
  final String description;

  const PostWidget({
    super.key,
    required this.userName,
    required this.time,
    required this.profileImage,
    required this.postImage,
    required this.description,
  });

  @override
  State<PostWidget> createState() => _PostWidgetState();
}

class _PostWidgetState extends State<PostWidget> {
  bool isLiked = false;
  bool isSaved = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              CircleAvatar(
                radius: 22,
                backgroundImage: AssetImage(widget.profileImage),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.userName,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Text(
                          widget.time,
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                        const SizedBox(width: 5),
                        const Icon(
                          Icons.public,
                          size: 13,
                          color: Colors.grey,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.more_horiz,
                  size: 27,
                ),
              ),
            ],
          ),
        ),

        if (widget.description.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(
              widget.description,
              style: const TextStyle(fontSize: 15),
            ),
          ),

        const SizedBox(height: 8),

        Image.asset(
          widget.postImage,
          width: double.infinity,
          height: 280,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            return Container(
              height: 280,
              width: double.infinity,
              color: Colors.grey.shade200,
              child: const Icon(
                Icons.image_not_supported,
                size: 50,
                color: Colors.grey,
              ),
            );
          },
        ),

        Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 8,
          ),
          child: Row(
            children: [
              const Icon(
                Icons.thumb_up,
                color: Color(0xFF1877F2),
                size: 18,
              ),
              const SizedBox(width: 5),
              const Text(
                'Like',
                style: TextStyle(color: Colors.grey),
              ),
              const Spacer(),
              const Text(
                'Comments',
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
        ),

        const Divider(height: 1),

        Row(
          children: [
            Expanded(
              child: TextButton.icon(
                onPressed: () {
                  setState(() {
                    isLiked = !isLiked;
                  });
                },
                icon: Icon(
                  isLiked
                      ? Icons.thumb_up
                      : Icons.thumb_up_outlined,
                  color: isLiked
                      ? const Color(0xFF1877F2)
                      : Colors.black87,
                ),
                label: Text(
                  'Like',
                  style: TextStyle(
                    color: isLiked
                        ? const Color(0xFF1877F2)
                        : Colors.black87,
                  ),
                ),
              ),
            ),
            Expanded(
              child: TextButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Comment clicked'),
                    ),
                  );
                },
                icon: const Icon(
                  Icons.mode_comment_outlined,
                  color: Colors.black87,
                ),
                label: const Text(
                  'Comment',
                  style: TextStyle(color: Colors.black87),
                ),
              ),
            ),
            Expanded(
              child: TextButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Share clicked'),
                    ),
                  );
                },
                icon: const Icon(
                  Icons.send_outlined,
                  color: Colors.black87,
                ),
                label: const Text(
                  'Share',
                  style: TextStyle(color: Colors.black87),
                ),
              ),
            ),
            IconButton(
              onPressed: () {
                setState(() {
                  isSaved = !isSaved;
                });
              },
              icon: Icon(
                isSaved
                    ? Icons.bookmark
                    : Icons.bookmark_border,
                color: isSaved
                    ? const Color(0xFF1877F2)
                    : Colors.black87,
              ),
            ),
          ],
        ),

        const Divider(
          height: 8,
          thickness: 5,
          color: Color(0xFFE4E6EB),
        ),
      ],
    );
  }
}
