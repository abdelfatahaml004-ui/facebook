
import 'package:flutter/material.dart';

class StoryWidget extends StatelessWidget {
  final String name;
  final String imagePath;
  final bool isCreateStory;

  const StoryWidget({
    super.key,
    required this.name,
    required this.imagePath,
    this.isCreateStory = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 105,
      margin: const EdgeInsets.symmetric(
        horizontal: 4,
        vertical: 8,
      ),
      child: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: SizedBox(
                    width: double.infinity,
                    height: double.infinity,
                    child: Image.asset(
                      imagePath,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          color: Colors.grey.shade300,
                          child: const Icon(
                            Icons.person,
                            size: 45,
                            color: Colors.grey,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                if (isCreateStory)
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 55,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.vertical(
                          bottom: Radius.circular(16),
                        ),
                      ),
                    ),
                  ),
                if (isCreateStory)
                  Positioned(
                    bottom: 39,
                    left: 0,
                    right: 0,
                    child: CircleAvatar(
                      radius: 13,
                      backgroundColor: Colors.white,
                      child: CircleAvatar(
                        radius: 11,
                        backgroundColor: Color(0xFF1877F2),
                        child: const Icon(
                          Icons.add,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                if (!isCreateStory)
                  Positioned(
                    top: 6,
                    left: 6,
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: const Color(0xFF1877F2),
                          width: 3,
                        ),
                      ),
                      child: CircleAvatar(
                        radius: 15,
                        backgroundImage: AssetImage(imagePath),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 5),
          Text(
            name,
            textAlign: TextAlign.center,
            maxLines: 2,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}
